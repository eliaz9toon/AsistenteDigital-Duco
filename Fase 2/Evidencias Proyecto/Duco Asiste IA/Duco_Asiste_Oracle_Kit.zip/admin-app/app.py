"""Aplicación local de administración CRUD para el esquema Oracle de Duco Asiste."""

from __future__ import annotations

import json
import os
import re
from contextlib import contextmanager
from datetime import datetime
from decimal import Decimal
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

try:
    import oracledb
except ImportError as exc:
    raise SystemExit("Falta python-oracledb. Instala dependencias con: pip install -r requirements.txt") from exc


ROOT = Path(__file__).resolve().parent


def load_dotenv() -> None:
    env_file = ROOT / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key.strip(), value)


load_dotenv()
oracledb.defaults.fetch_lobs = False


def connect():
    user = os.getenv("ORACLE_USER")
    password = os.getenv("ORACLE_PASSWORD")
    dsn = os.getenv("ORACLE_DSN")
    if not user or not password or not dsn:
        raise RuntimeError("Configura ORACLE_USER, ORACLE_PASSWORD y ORACLE_DSN en admin-app/.env")
    return oracledb.connect(user=user, password=password, dsn=dsn)


@contextmanager
def db_session():
    connection = connect()
    try:
        yield connection
    finally:
        connection.close()


def safe_ident(name: str) -> str:
    if not re.fullmatch(r"[A-Z][A-Z0-9_$#]{0,127}", name):
        raise ValueError("Identificador Oracle inválido")
    return f'"{name}"'


def table_names(conn) -> list[str]:
    with conn.cursor() as cur:
        cur.execute("SELECT table_name FROM user_tables ORDER BY table_name")
        return [row[0] for row in cur]


def table_meta(conn, table: str) -> dict:
    table = table.upper()
    if table not in table_names(conn):
        raise ValueError("La tabla no existe en el esquema conectado")
    with conn.cursor() as cur:
        cur.execute("""
            SELECT column_name, data_type, nullable, identity_column
            FROM user_tab_columns WHERE table_name = :table_name ORDER BY column_id
        """, table_name=table)
        columns = [
            {"name": row[0], "type": row[1], "nullable": row[2] == "Y", "identity": row[3] == "YES"}
            for row in cur
        ]
        cur.execute("""
            SELECT column_name FROM user_cons_columns
            WHERE table_name = :table_name AND constraint_name IN (
                SELECT constraint_name FROM user_constraints
                WHERE table_name = :table_name AND constraint_type = 'P'
            ) ORDER BY position
        """, table_name=table)
        primary_key = [row[0] for row in cur]
    if not primary_key:
        raise ValueError("No se puede editar una tabla sin clave primaria")
    return {"name": table, "columns": columns, "primaryKey": primary_key}


def normalize(value, data_type: str):
    if value is None or value == "":
        return None
    if data_type == "NUMBER":
        return Decimal(str(value))
    if data_type == "DATE":
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if data_type.startswith("TIMESTAMP"):
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return value


class Handler(BaseHTTPRequestHandler):
    server_version = "DucoAdmin/1.0"

    def log_message(self, format, *args):
        print("[Duco Admin]", format % args)

    def send_json(self, status: int, payload) -> None:
        body = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def body_json(self) -> dict:
        length = min(int(self.headers.get("Content-Length", "0")), 1_000_000)
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        if path == "/" or path == "/index.html":
            return self.serve_index()
        try:
            with db_session() as conn:
                if path == "/api/tables":
                    return self.send_json(200, {"tables": table_names(conn)})
                match = re.fullmatch(r"/api/tables/([A-Za-z0-9_$#]+)/rows", path)
                if match:
                    meta = table_meta(conn, match.group(1))
                    qtable = safe_ident(meta["name"])
                    with conn.cursor() as cur:
                        cur.execute(f"SELECT * FROM {qtable} FETCH FIRST 200 ROWS ONLY")
                        names = [col[0] for col in cur.description]
                        rows = [dict(zip(names, row)) for row in cur]
                    return self.send_json(200, {"meta": meta, "rows": rows, "limit": 200})
            self.send_json(404, {"error": "Ruta no encontrada"})
        except Exception as exc:
            self.send_json(400, {"error": str(exc)})

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        match = re.fullmatch(r"/api/tables/([A-Za-z0-9_$#]+)", path)
        if not match:
            return self.send_json(404, {"error": "Ruta no encontrada"})
        try:
            payload = self.body_json()
            with db_session() as conn:
                meta = table_meta(conn, match.group(1))
                values = self.clean_values(meta, payload.get("values", {}), allow_pk=True)
                if not values:
                    raise ValueError("Ingresa al menos un valor")
                columns = list(values)
                binds = {f"v{i}": normalize(values[name], self.col_type(meta, name)) for i, name in enumerate(columns)}
                names_sql = ", ".join(safe_ident(name) for name in columns)
                binds_sql = ", ".join(f":v{i}" for i in range(len(columns)))
                with conn.cursor() as cur:
                    cur.execute(f"INSERT INTO {safe_ident(meta['name'])} ({names_sql}) VALUES ({binds_sql})", binds)
                conn.commit()
            self.send_json(201, {"ok": True})
        except Exception as exc:
            self.send_json(400, {"error": str(exc)})

    def do_PUT(self):
        path = unquote(urlparse(self.path).path)
        match = re.fullmatch(r"/api/tables/([A-Za-z0-9_$#]+)", path)
        if not match:
            return self.send_json(404, {"error": "Ruta no encontrada"})
        try:
            payload = self.body_json()
            with db_session() as conn:
                meta = table_meta(conn, match.group(1))
                key = payload.get("key", {})
                if not all(column in key for column in meta["primaryKey"]):
                    raise ValueError("Falta la clave primaria del registro")
                values = self.clean_values(meta, payload.get("values", {}), allow_pk=False)
                if not values:
                    raise ValueError("No hay cambios para guardar")
                binds = {f"v{i}": normalize(values[name], self.col_type(meta, name)) for i, name in enumerate(values)}
                sets = ", ".join(f"{safe_ident(name)} = :v{i}" for i, name in enumerate(values))
                where_parts = []
                for i, name in enumerate(meta["primaryKey"]):
                    binds[f"k{i}"] = normalize(key[name], self.col_type(meta, name))
                    where_parts.append(f"{safe_ident(name)} = :k{i}")
                with conn.cursor() as cur:
                    cur.execute(f"UPDATE {safe_ident(meta['name'])} SET {sets} WHERE {' AND '.join(where_parts)}", binds)
                    if cur.rowcount != 1:
                        raise ValueError("No se encontró el registro")
                conn.commit()
            self.send_json(200, {"ok": True})
        except Exception as exc:
            self.send_json(400, {"error": str(exc)})

    def do_DELETE(self):
        path = unquote(urlparse(self.path).path)
        match = re.fullmatch(r"/api/tables/([A-Za-z0-9_$#]+)", path)
        if not match:
            return self.send_json(404, {"error": "Ruta no encontrada"})
        try:
            payload = self.body_json()
            with db_session() as conn:
                meta = table_meta(conn, match.group(1))
                key = payload.get("key", {})
                if not all(column in key for column in meta["primaryKey"]):
                    raise ValueError("Falta la clave primaria del registro")
                binds, parts = {}, []
                for i, name in enumerate(meta["primaryKey"]):
                    binds[f"k{i}"] = normalize(key[name], self.col_type(meta, name))
                    parts.append(f"{safe_ident(name)} = :k{i}")
                with conn.cursor() as cur:
                    cur.execute(f"DELETE FROM {safe_ident(meta['name'])} WHERE {' AND '.join(parts)}", binds)
                    if cur.rowcount != 1:
                        raise ValueError("No se encontró el registro")
                conn.commit()
            self.send_json(200, {"ok": True})
        except Exception as exc:
            self.send_json(400, {"error": str(exc)})

    @staticmethod
    def col_type(meta: dict, name: str) -> str:
        return next(col["type"] for col in meta["columns"] if col["name"] == name)

    @staticmethod
    def clean_values(meta: dict, values: dict, allow_pk: bool) -> dict:
        if not isinstance(values, dict):
            raise ValueError("Los datos del formulario no son válidos")
        known = {col["name"] for col in meta["columns"]}
        identity = {col["name"] for col in meta["columns"] if col["identity"]}
        pk = set(meta["primaryKey"])
        unknown = set(values) - known
        if unknown:
            raise ValueError("Se recibieron columnas desconocidas")
        if set(values) & identity or (not allow_pk and set(values) & pk):
            raise ValueError("No se puede modificar una clave generada o clave primaria")
        return values

    def serve_index(self):
        content = (ROOT / "index.html").read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)


def main():
    port = int(os.getenv("ADMIN_PORT", "8765"))
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"Duco Admin disponible en http://127.0.0.1:{port}")
    print("Solo escucha en localhost. Usa Ctrl+C para cerrar.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nCerrando Duco Admin…")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
