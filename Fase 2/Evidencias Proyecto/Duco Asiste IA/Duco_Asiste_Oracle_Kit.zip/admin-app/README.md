# Duco Admin local

Aplicación CRUD local para revisar y modificar las tablas del esquema Oracle conectado. Se sirve en `127.0.0.1` y usa la conexión configurada en el backend; las credenciales no se guardan en el navegador.

## Requisitos

- Python 3.10 o posterior.
- Oracle Database XE/Free iniciado y el esquema Duco instalado desde `../database/oracle/schema.sql`.
- Acceso de red local a la dirección de servicio Oracle configurada.

## Inicio en Windows PowerShell

Desde la carpeta `admin-app`:

```powershell
Copy-Item .env.example .env
notepad .env
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

En `.env`, configura `ORACLE_USER`, `ORACLE_PASSWORD` y `ORACLE_DSN`. XE suele usar `localhost:1521/XEPDB1`; Oracle Database Free suele usar `localhost:1521/FREEPDB1`. Abre `http://127.0.0.1:8765` en el navegador. Cierra la aplicación con `Ctrl+C` en la terminal.

La interfaz muestra hasta 200 filas por tabla y permite insertar, editar y eliminar. Oracle valida las claves foráneas y restricciones; si un registro está relacionado, la interfaz muestra el error y no oculta el fallo. La aplicación se liga únicamente a localhost: no la expongas a una red compartida sin añadir autenticación y controles de seguridad.

Si no conecta, comprueba que Oracle esté iniciado, que el DSN incluya el service name de la PDB y que el usuario `DUCO_APP` tenga el esquema instalado. La conexión usa el modo Thin de `python-oracledb`, que no requiere instalar Oracle Instant Client.
