# Base de datos Oracle de Duco Asiste

El ZIP original se conserva en `database/source/`. El documento y el diagrama describen un modelo propuesto de 30 tablas; no contienen una base ya instalada ni datos de producción. `oracle/schema.sql` adapta el DDL original para Oracle 12c o posterior y agrega columnas identity a las 27 claves primarias simples, para que Oracle genere sus valores automáticamente. Las tres tablas de relación conservan sus claves primarias compuestas. No se incluyen datos ficticios.

## Descargas oficiales

- [Oracle AI Database Free 26ai para Windows](https://www.oracle.com/database/free/): es el servidor local de base de datos.
- [Oracle SQL Developer](https://www.oracle.com/database/sqldeveloper/): es el cliente con Data Modeler para ejecutar los scripts y generar/editar el diagrama. Para Windows, el paquete ZIP que incluye JDK evita instalar Java por separado.

Descarga e instala ambos componentes desde Oracle. SQL Developer por sí solo no crea ni ejecuta un servidor de base de datos.

## Crear el esquema local

1. Instala Oracle Database XE o Oracle Database Free y recuerda el nombre del servicio PDB. SQL Developer es el cliente; no sustituye al servidor Oracle.
2. En SQL Developer crea una conexión administrativa a la PDB (por ejemplo `localhost:1521/XEPDB1` para XE o `localhost:1521/FREEPDB1` para Free).
3. Abre y ejecuta `oracle/create_user.sql` como `SYSTEM`. Reemplaza la contraseña de ejemplo por una propia antes de ejecutarlo.
4. Crea una conexión nueva como `DUCO_APP` y ejecuta `oracle/schema.sql`. El script crea las 30 tablas y sus claves foráneas; no borra objetos existentes, por lo que debe ejecutarse en un esquema vacío.
5. Verifica que el panel Tables muestre 30 tablas.

No se pudo iniciar o validar Oracle en el entorno actual: SQL*Plus, SQLcl y Docker no están instalados aquí. Los scripts deben ejecutarse contra tu instancia Oracle local para crear realmente la base.

## SQL Developer Data Modeler

El DDL usa tipos y sintaxis Oracle, e importa como modelo relacional. Para generar el diagrama desde el script, abre Data Modeler y elige **File → Import → DDL File**, agrega `oracle/schema.sql` y termina el asistente. Para extraer un modelo desde el esquema ya creado, usa **File → Import → Data Dictionary**, selecciona la conexión `DUCO_APP` y luego las 30 tablas. Guarda el diseño resultante como `.dmd` desde Data Modeler. Oracle describe ambas opciones como flujos de modelado bottom-up: importar DDL o extraer el diccionario de una base. Consulta [la guía oficial de Data Modeler](https://docs.oracle.com/en/database/oracle/sql-developer-data-modeler/24.3/dmdug/data-modeler-concepts-usage.html).

## Consola administrativa

Consulta `../admin-app/README.md` para iniciar la aplicación local de altas, consultas, edición y eliminación de registros.
