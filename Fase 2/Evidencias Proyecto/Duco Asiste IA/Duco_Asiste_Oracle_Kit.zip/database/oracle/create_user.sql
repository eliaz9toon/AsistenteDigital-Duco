-- Ejecutar conectado al servicio PDB como SYSTEM o un usuario con CREATE USER.
-- Cambia la contraseña de ejemplo antes de ejecutarlo.
CREATE USER DUCO_APP IDENTIFIED BY "Cambia_Esta_Clave_123";
GRANT CREATE SESSION, CREATE TABLE TO DUCO_APP;
ALTER USER DUCO_APP QUOTA UNLIMITED ON USERS;

-- Luego conecta SQL Developer como DUCO_APP y ejecuta schema.sql.
